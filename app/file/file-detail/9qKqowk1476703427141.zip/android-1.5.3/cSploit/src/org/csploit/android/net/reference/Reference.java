package org.csploit.android.net.reference;

/**
 * a reference to something
 *
 * TODO: getDrawableResourceId
 */
public interface Reference {
  public String getName();
  public String getSummary();
}
