cSploit - An Android network penetration suite.
==============================

Copyleft Margaritelli of Simone aka evilsocket and then fused with zANTI2 continued by tux-mind.

- <http://www.csploit.org/>

[![Click here to lend your support to: cSploit and make a donation at www.paypal.com](https://www.paypalobjects.com/en_GB/i/btn/btn_donate_LG.gif?skin_name=chrome)](https://www.paypal.com/uk/cgi-bin/webscr?cmd=_flow&SESSION=BBgUDlBOyEpm2SBPeuhVH1hHoyi9MORuTT2tAq-WBPfZFlhoXxa1AymS0je&dispatch=5885d80a13c0db1f8e263663d3faee8d66f31424b43e9a70645c907a6cbd8fb4)

-------------

cSploit is an Android network analysis and penetration suite which aims to offer to IT security experts/geeks
**the most complete and advanced professional toolkit** to perform network security assesments on a mobile device.

Once cSploit is started, you will be able to easily map your network, fingerprint alive hosts operating systems
and running services, search for **known vulnerabilities**, crack logon procedures of many tcp protocols, perform
man in the middle attacks such as **password sniffing** ( with common protocols dissection ), real time **traffic
manipulation**, etc, etc .

This application is still in **beta stage**, a stable release will be available as soon as possible, but expect
some crash or strange behaviour until then, in any case, feel free to submit an issue here on GitHub.

Requirements
-------------

- An Android device with at least the 2.3 ( Gingerbread ) version of the OS.
- The device **must be rooted**.
- The device must have a BusyBox **full install**, this means with **every** utility installed ( not the partial installation ).


Disclaimer
-------------

This application is not to be used for any purposes other than to demonstrate its functions, and must only be used on networks for which you have permission to do so. Any other use is not the responsibility of the developer.In other words, don't be stupid, and don't direct angry people towards me.

License
-------------

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
